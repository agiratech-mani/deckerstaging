window.onmessage = function(e) {
  switch (e.data) {
  case 'record':
    //document.VideoRecorder.startRecorder();
    document.VideoRecorder.record();
    break;
  case 'pauseRecording':
    document.VideoRecorder.pauseRecording();
    break;
  case 'resumeRecording':
    document.VideoRecorder.resumeRecording();
    break;
  case 'stopVideo':
    document.VideoRecorder.stopVideo();
    break;
  case 'playVideo':
    document.VideoRecorder.playVideo();
    break;
  case 'pause':
    document.VideoRecorder.pause();
    break;
  case 'save':
    document.VideoRecorder.save();
    break;
  case 'startRecording':
    document.VideoRecorder.startRecording();
    break;
  }
};

function sendMessage(data) {
  window.top.postMessage(data, '*');
}

var flashvars = {
  userId : "XXY",
  qualityurl : "audio_video_quality_profiles/320x240x30x90.xml",
  recorderId : window.vrecorderClass, //window.location.search.substring(1),
  sscode : "php",
  lstext : "Loading Settings..."
};
var params = {
  quality : "high",
  bgcolor : "#dfdfdf",
  play : "true",
  loop : "false",
  allowscriptaccess : "sameDomain",
  skipInitialScreen : 1
};
var attributes = {
  name : "VideoRecorder",
  id : "VideoRecorder",
  align : "middle"
};

var mobile = false;
var ua = navigator.userAgent.toLowerCase();
if (navigator.appVersion.indexOf("iPad") != -1
    || navigator.appVersion.indexOf("iPhone") != -1
    || ua.indexOf("android") != -1 || ua.indexOf("ipod") != -1
    || ua.indexOf("windows ce") != -1 || ua.indexOf("windows phone") != -1) {
  mobile = true;
}

if (mobile == false) {
  swfobject.embedSWF("VideoRecorder.swf", "flashContent", "320", "240",
      "10.3.0", "", flashvars, params, attributes);
} else {
  //do nothing
}

$(document)
    .ready(
        function() {
          var options = {
            target : '#output',
            beforeSubmit : beforeSubmit,
            success : afterSuccess,
            uploadProgress : OnProgress,
            resetForm : true
          };

          $('#recordingForm').submit(function() {
            $(this).ajaxSubmit(options);

            return false;
          });

          $('#recorderVideo').hide();

          function afterSuccess() {
            $('#submit-btn').show();
            $('#recorderVideo').show();
            $('#loading-img').hide();
            $('#progressbox').delay(1000).fadeOut();
            fileName = document.getElementById("output").innerHTML;
            var res = fileName.split("#");
            var video = document.getElementById("recorderVideo");
            video.setAttribute("src", "mobileRecordings/" + res[0]);
          }

          function beforeSubmit() {

            if (window.File && window.FileReader && window.FileList
                && window.Blob) {

              if (!$('#FileInput').val()) {
                $("#output").html("Are you kidding me?");
                return false
              }

              var fsize = $('#FileInput')[0].files[0].size;
              var ftype = $('#FileInput')[0].files[0].type;

              switch (ftype) {
              case 'video/mp4':
              case 'video/quicktime':
                break;
              default:
                $("#output")
                    .html("<b>" + ftype + "</b> Unsupported file type!");
                return false
              }

              /*if(fsize>5242880) 
              {
                $("#output").html("<b>"+bytesToSize(fsize) +"</b> Too big file! <br />File is too big, it should be less than 5 MB.");
                return false
              }*/

              $('#submit-btn').hide();
              $('#loading-img').show();
              $("#output").html("");
            } else {
              $("#output")
                  .html(
                      "Please upgrade your browser, because your current browser lacks some new features we need!");
              return false;
            }
          }

          function OnProgress(event, position, total, percentComplete) {
            $('#progressbox').show();
            $('#progressbar').width(percentComplete + '%')
            $('#statustxt').html(percentComplete + '%');
            if (percentComplete > 50) {
              $('#statustxt').css('color', '#000');
            }
          }

          function bytesToSize(bytes) {
            var sizes = [ 'Bytes', 'KB', 'MB', 'GB', 'TB' ];
            if (bytes == 0)
              return '0 Bytes';
            var i = parseInt(Math.floor(Math.log(bytes) / Math.log(1024)));
            return Math.round(bytes / Math.pow(1024, i), 2) + ' ' + sizes[i];
          }

        });

// This script below is used to prevent the web-cam remaining active on Internet Explorer 
window.onbeforeunload = function() {
  if (navigator.appName == 'Microsoft Internet Explorer') {
    var swf = document.getElementById('VideoRecorder');
    swf.disconnectAndRemove();
  }
}

function userHasCamMic(cam_number, mic_number, recorderId) {
  //this function is called when HDFVR is initialized
  //recorderId: the recorderId sent via flash vars, to be used when there are many recorders on the same web page
  sendMessage( {
    evt : 'userHasCamMic',
    cam_number : cam_number,
    mic_number : mic_number,
    recorderId : recorderId
  });
}

function btRecordPressed(recorderId) {
  //this function is called whenever the Record button is pressed to start a recording
  //recorderId: the recorderId sent via flash vars, to be used when there are many recorders on the same web page
  sendMessage( {
    evt : 'btRecordPressed',
    recorderId : recorderId
  });
}

function btStopRecordingPressed(recorderId) {
  //this function is called whenever a recording is stopped
  //recorderId: the recorderId sent via flash vars, to be used when there are many recorders on the same web page
  sendMessage( {
    evt : 'btStopRecordingPressed',
    recorderId : recorderId
  });
}

function btPlayPressed(recorderId) {
  //this function is called whenever the Play button is pressed to start/resume playback
  //recorderId: the recorderId sent via flash vars, to be used when there are many recorders on the same web page
  sendMessage( {
    evt : 'btPlayPressed',
    recorderId : recorderId
  });
}

function btPausePressed(recorderId) {
  //this function is called whenever the Pause button is pressed during playback
  //recorderId: the recorderId sent via flash vars, to be used when there are many recorders on the same web page
  sendMessage( {
    evt : 'btPausePressed',
    recorderId : recorderId
  });
}

function btPauseRecordingPressed(recorderId) {
  //console.log("btPauseRecordingPressed()" + recorderId );
  sendMessage( {
    evt : 'btPauseRecordingPressed',
    recorderId : recorderId
  });
}

function btResumeRecordingPressed(recorderId) {
  //console.log("btResumeRecordingPressed()" + recorderId );
  sendMessage( {
    evt : 'btResumeRecordingPressed',
    recorderId : recorderId
  });
}

function onUploadDone(streamName, streamDuration, userId, recorderId,
    audioCodec, videoCodec, fileType) {
  sendMessage( {
    evt : 'onUploadDone',
    streamName : streamName,
    streamDuration : streamDuration,
    userId : userId,
    recorderId : recorderId,
    audioCodec : audioCodec,
    videoCodec : videoCodec,
    fileType : fileType
  });

  //this function is called when the video/audio stream has been all sent to the video server and has been saved to the video server HHD, 
  //on slow client->server connections, because the data can not reach the video server in real time, it is stored in the recorder's buffer until it is sent to the server, you can configure the buffer size in avc_settings.XXX

  //this function is called with 7 parameters: 
  //streamName: a string representing the name of the stream recorded on the video server WITHOUT the filename extension (.flv , .f4v or .mp4)
  //userId: the userId sent via flash vars or via the avc_settings.XXX file, the value in the avc_settings.XXX file takes precedence if its not empty
  //duration of the recorded video/audio file in seconds but acccurate to the millisecond (like this: 4.322)
  //recorderId: the recorderId sent via flash vars, to be used when there are many recorders on the same web page
  //audioCodec: the audio codec used for the recording, Nelly Moser or Speex
  //videoCodec: the video codec used for the recording, Sorenson or H.264
  //fileType: the format in which the resulting recording will be saved in: FLV, F4V or MP4
}

function onSaveOk(streamName, streamDuration, userId, cameraName, micName,
    recorderId, audioCodec, videoCodec, fileType) {
  sendMessage( {
    evt : 'onSaveOk',
    streamName : streamName,
    streamDuration : streamDuration,
    userId : userId,
    cameraName : cameraName,
    micName : micName,
    recorderId : recorderId,
    audioCodec : audioCodec,
    videoCodec : videoCodec,
    fileType : fileType
  });

  //the user pressed the [save] button inside the recorder and the save_video_to_db.XXX script returned save=ok
  //recorderId: the recorderId sent via flash vars, to be used when there are many recorders on the same web page
  //audioCodec: the audio codec used for the recording, Nelly Moser or Speex
  //videoCodec: the video codec used for the recording, Sorenson or H.264
  //fileType: the format in which the resulting recording will be saved in: FLV, F4V or MP4
}

function onSaveFailed(streamName, streamDuration, userId, recorderId) {
  //the user pressed the [save] button inside the recorder but the save_video_to_db.XXX script returned save=fail
  //recorderId: the recorderId sent via flash vars, to be used when there are many recorders on the same web page
  sendMessage( {
    evt : 'onSaveFailed',
    streamName : streamName,
    streamDuration : streamDuration,
    userId : userId,
    recorderId : recorderId
  });
}

function onSaveJpgOk(streamName, userId, recorderId) {
  //the user pressed the [save] button inside the recorder and the jpg_encoder_download.XXX script returned save=ok
  //recorderId: the recorderId sent via flash vars, to be used when there are many recorders on the same web page
  sendMessage( {
    evt : 'onSaveJpgOk',
    streamName : streamName,
    userId : userId,
    recorderId : recorderId
  });
}

function onSaveJpgFailed(streamName, userId, recorderId) {
  //the user pressed the [save] button inside the recorder but the jpg_encoder_download.XXX script returned save=fail
  //recorderId: the recorderId sent via flash vars, to be used when there are many recorders on the same web page
  sendMessage( {
    evt : 'onSaveJpgFailed',
    streamName : streamName,
    userId : userId,
    recorderId : recorderId
  });
}

function onFlashReady(recorderId) {
  //you can now communicate with HDFVR using the JS Control API
  //Example : document.VideoRecorder.record(); will make a call to flash in order to start recording
  //recorderId: the recorderId sent via flash vars, to be used when there are many recorders on the same web page
  sendMessage( {
    evt : 'onFlashReady',
    recorderId : recorderId
  });
}

function onPlaybackComplete(recorderId) {
  //this function is called when HDFVR plays back a recorded video and the playback completes
  //recorderId: the recorderId sent via flash vars, to be used when there are many recorders on the same web page
  sendMessage( {
    evt : 'onPlaybackComplete',
    recorderId : recorderId
  });
}

function onRecordingStarted(recorderId) {
  //this function is called when HDFVR starts recording
  //recorderId: the recorderId sent via flash vars, to be used when there are many recorders on the same web page
  sendMessage( {
    evt : 'onRecordingStarted',
    recorderId : recorderId
  });
}

function onCamAccess(allowed, recorderId) {
  sendMessage( {
    evt : 'onCamAccess',
    allowed : allowed,
    recorderId : recorderId
  });
  //the user clicked Allow or Deny in the Camera/Mic access dialog box in Flash Player
  //when the user clicks Deny this function is called with allowed=false
  //when the user clicks Allow this function is called with allowed=true
  //you should wait for this function before allowing the user to cal the record() function on HDFVR
  //this function can be called anytime during the life of the HDFVR instance as the user has permanent access to the Camera/Mic access dialog box in Flash Player
  //recorderId: the recorderId sent via flash vars, to be used when there are many recorders on the same web page
  if (allowed) {
    document.getElementById("recordbtn").disabled = false
  } else {
    document.getElementById("recordbtn").disabled = true
  }
}

function onFPSChange(recorderId, currentFPS) {
  sendMessage( {
    evt : 'onFPSChange',
    recorderId : recorderId,
    currentFPS : currentFPS
  });
  //this function is called by HDFVR every second
  //currentFPS:the current frames-per-second that HDFVR reports (during recording, playback, uploading and saving) depending of the state of HDFVR.
  //recorderId: the recorderId sent via flash vars, to be used when there are many recorders on the same web page
}

function onConnectionClosed(recorderId) {
  //this function is called by HDFVR when the connection to the media server has been lost
  //recorderId: the recorderId sent via flash vars, to be used when there are many recorders on the same web page
  sendMessage( {
    evt : 'onConnectionClosed',
    recorderId : recorderId
  });
}

function onConnectionStatus(status, recorderId) {
  //this function is called by HDFVR for every connection event.
  //status: the actual connection status: (connected, rejected, invalid app, closed, failed)
  //recorderId: the recorderId sent via flash vars, to be used when there are many recorders on the same web page
  sendMessage( {
    evt : 'onConnectionStatus',
    status : status,
    recorderId : recorderId
  });
}

function onMicActivityLevel(recorderId, currentActivityLevel) {
  //this function is called by HDFVR every second
  //currentActivityLevel:The amount of sound the microphone is detecting
  //recorderId: the recorderId sent via flash vars, to be used when there are many recorders on the same web page
  sendMessage( {
    evt : 'onMicActivityLevel',
    recorderId : recorderId,
    currentActivityLevel : currentActivityLevel
  });
}

function onFFMPEGConversionFinished(recorderId, status, streamName) {
  //this function is called by HDFVR after the conversion with FFMPEG has finished server side
  //recorderId: the recorderId sent via flash vars, to be used when there are many recorders on the same web page
  //status: the status when the conversion is finished: success or fail
  //streamName: the name of the stream for which the conversion finished
  sendMessage( {
    evt : 'onFFMPEGConversionFinished',
    recorderId : recorderId,
    status : status,
    streamName : streamName
  });
}